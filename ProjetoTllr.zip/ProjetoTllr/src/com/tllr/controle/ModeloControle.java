package com.tllr.controle;
import com.tllr.persistencia.IModeloDao;
import com.tllr.modelos.Modelo;
import com.tllr.persistencia.MarcaDao;
import java.util.ArrayList;
import com.tllr.persistencia.ModelosDao;
public class ModeloControle implements IModeloControle{
        IModeloDao modeloPersistencia = null;
    
        public ModeloControle(){
        this.modeloPersistencia = new ModelosDao();
    }
   
        @Override
    public void incluir(Modelo objeto) throws Exception {
        

    }

    @Override
    public void alterar(Modelo objeto) throws Exception {
        

    }

    @Override
    public void nada(Modelo desc) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public ArrayList<Modelo> listagemModelos() throws Exception {
        return modeloPersistencia.listagemModelo();
    }
    
}
